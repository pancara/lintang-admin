using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Krystalware.SlickUpload;
using AspNetMvcRazorCs.Models;

namespace AspNetMvcRazorCs.Controllers
{
    public class ClientApiController : Controller
    {
        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult UploadResult(UploadSession session)
        {
            
            return View(session);
        }
        

        
    }
}
