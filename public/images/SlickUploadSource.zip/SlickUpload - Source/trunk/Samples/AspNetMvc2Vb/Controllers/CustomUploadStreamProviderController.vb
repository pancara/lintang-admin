Imports Krystalware.SlickUpload
Imports AspNetMvc2Vb.Models

Public Class CustomUploadStreamProviderController
    Inherits System.Web.Mvc.Controller

    
    Public Function Index() As ActionResult
        Return View()
    End Function

    Public Function UploadResult(session As UploadSession) As ActionResult
        
        Return View(session)
    End Function
    

        
End Class
