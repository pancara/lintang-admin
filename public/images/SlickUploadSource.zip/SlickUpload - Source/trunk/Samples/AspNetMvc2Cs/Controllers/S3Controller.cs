using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Krystalware.SlickUpload;
using AspNetMvc2Cs.Models;

namespace AspNetMvc2Cs.Controllers
{
    public class S3Controller : Controller
    {
        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult UploadResult(UploadSession session)
        {
            
            return View(session);
        }
        

        
    }
}
