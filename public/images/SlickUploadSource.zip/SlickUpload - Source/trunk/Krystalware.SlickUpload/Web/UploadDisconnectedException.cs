﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Krystalware.SlickUpload.Web
{
    /// <summary>
    /// Represents an upload disconnection error.
    /// </summary>
    public class UploadDisconnectedException : Exception
    {

    }
}
