﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Krystalware.SlickUpload.Web
{
    /// <summary>
    /// Represents an upload cancellation error.
    /// </summary>
    public class UploadCancelledException : Exception
    {

    }
}
